﻿namespace EngineAnalyticsWebApp.UI.Components.Pages.Engine
{
    public partial class CalculateHorsepower
    {
        private string title = "Engine Horsepower Calculation";
    }
}
