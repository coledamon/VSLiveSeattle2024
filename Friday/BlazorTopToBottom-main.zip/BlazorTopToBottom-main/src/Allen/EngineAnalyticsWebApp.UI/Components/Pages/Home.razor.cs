﻿namespace EngineAnalyticsWebApp.UI.Components.Pages
{
    public partial class Home
    {
        private readonly string title = "Welcome to the Engine Analytics Blazor App";
    }
}
