﻿namespace EngineAnalyticsWebApp.UI.Components.Pages.Engine
{
    public partial class CalculateDisplacement
    {
        private string title = "Engine Displacement Calculation";
    }
}
