﻿namespace EngineAnalyticsWebApp.UI.Components.Pages.Reports
{
    public partial class TorqueResults
    {
        private string title = "Torque Results";
    }
}
