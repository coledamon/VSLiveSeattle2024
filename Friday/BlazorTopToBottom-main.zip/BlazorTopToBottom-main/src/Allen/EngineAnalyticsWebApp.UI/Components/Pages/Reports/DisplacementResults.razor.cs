﻿namespace EngineAnalyticsWebApp.UI.Components.Pages.Reports
{
    public partial class DisplacementResults
    {
        private string title = "Displacement Results";
    }
}
