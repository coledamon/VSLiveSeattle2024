﻿namespace EngineAnalyticsWebApp.UI.Components.Pages.Reports
{
    public partial class HorsepowerResults
    {
        private string title = "Horsepower Results";
    }
}
