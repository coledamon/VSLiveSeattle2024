﻿namespace EngineAnalyticsWebApp.UI.Components.Pages.Engine
{
    public partial class CalculateTorque
    {
        private string title = "Engine Torque Calculation";
    }
}
