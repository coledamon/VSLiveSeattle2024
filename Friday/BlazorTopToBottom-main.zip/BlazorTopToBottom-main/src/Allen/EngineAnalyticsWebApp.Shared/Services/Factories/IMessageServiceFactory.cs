﻿namespace EngineAnalyticsWebApp.Shared.Services.Factories
{
    public interface IMessageServiceFactory
    {
        IMessageService Create();
    }
}
