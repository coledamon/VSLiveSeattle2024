﻿
namespace EngineAnalyticsWebApp.Shared.Services
{
    public interface IMessageService
    {
        string MessageLogger(string message);
    }
}
