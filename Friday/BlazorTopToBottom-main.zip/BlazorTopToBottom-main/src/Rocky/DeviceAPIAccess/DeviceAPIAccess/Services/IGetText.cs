﻿namespace DeviceAPIAccess.Services
{
  public interface IGetText
  {
    string GetText();
  }
}
