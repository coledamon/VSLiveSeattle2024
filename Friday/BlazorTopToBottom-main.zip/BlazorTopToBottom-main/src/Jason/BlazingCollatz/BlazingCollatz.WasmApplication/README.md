# .NET WASM Application

## Build

You can build the app from Visual Studio or from the command-line:

```
dotnet build -c Debug/Release
```

## Run

You can run the app from Visual Studio or the command-line:

```
dotnet run -c Debug/Release
```