﻿namespace BlazingCollatz.AvaloniaApplication.ViewModels
{
   public class MainViewModel : ViewModelBase
   {
	  public string Greeting => "Welcome to Avalonia!";
   }
}