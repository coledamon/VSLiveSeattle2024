﻿using ReactiveUI;

namespace BlazingCollatz.AvaloniaApplication.ViewModels
{
   public class ViewModelBase : ReactiveObject
   {
   }
}