using Avalonia.Controls;

namespace BlazingCollatz.AvaloniaApplication.Views
{
   public partial class MainWindow : Window
   {
	  public MainWindow()
	  {
		 InitializeComponent();
	  }
   }
}