﻿namespace eShop.WebApp.Services;

public class LogOutService
{
    public async Task LogOutAsync(HttpContext httpContext)
    {
        await Task.CompletedTask;
    }
}
