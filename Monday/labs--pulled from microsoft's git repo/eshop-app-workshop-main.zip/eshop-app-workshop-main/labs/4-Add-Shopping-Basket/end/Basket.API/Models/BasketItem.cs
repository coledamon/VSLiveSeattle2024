﻿namespace eShop.Basket.API.Models;

public class BasketItem
{
    public int ProductId { get; set; }

    public int Quantity { get; set; }
}
