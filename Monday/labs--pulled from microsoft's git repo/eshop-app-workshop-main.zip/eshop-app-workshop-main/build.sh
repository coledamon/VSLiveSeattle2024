#!/usr/bin/env bash

dotnet workload install aspire

dotnet build ./build/Build.proj